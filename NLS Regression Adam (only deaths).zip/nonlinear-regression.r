setwd("C:/Users/adam/Blakey Cloud/Documents/Education/University of Nottingham/PhD/G14UQN/P1 SEIR Model/G14UQN-Project1/")

# ODE solver.
library("deSolve")
library("minpack.lm")
source("./ODE-solver.r")

# Initial guess at parameters.
parameters <- c(sigma=1/9, beta=0.75, p=0.25, gamma=1/9)
initial    <- c(S=2799, E=0, I=1, R=0, C=0, D=0)

# Time range.
t_range = seq(0, 198, by=1)

# Reads in the data.
data <- read.csv("./data/Data_groupA.txt", sep="")

# ODE solver for cases and deaths, taking only the unknown parameters as inputs.
ode_solve <- function(beta, p, gamma)
{
  parm <- c(sigma=parameters[["sigma"]], beta=beta, p=p, gamma=gamma)
  SEIRCD_solution <- rk4(initial, t_range, SEIRCD, parm)
  
  C <- SEIRCD_solution[, "C"]
  D <- SEIRCD_solution[, "D"]
  
  return(D)
}

fit=nlsLM(deaths~ode_solve(beta, p, gamma), data=c(cumsum(data[2]), cumsum(data[3])), start=parameters[c(2, 3, 4)], control=c("nprint"=1, "maxiter"=50))
updated_parameters <- c(sigma=parameters[["sigma"]], beta=coef(fit)[["beta"]], p=coef(fit)[["p"]], gamma=coef(fit)[["gamma"]])

# Solves equation with updated parameters.
SIER_solution <- rk4(y=initial, times=t_range, func=SEIRCD, parms=updated_parameters)

# Copies outputs to match nice names.
t      <- t_range
t_data <- data[, 1]
S_mod  <- SIER_solution[, "S"]
E_mod  <- SIER_solution[, "E"]
I_mod  <- SIER_solution[, "I"]
R_mod  <- SIER_solution[, "R"]
C_data <- cumsum(data[, 2])
C_mod  <- SIER_solution[, "C"]
D_data <- cumsum(data[, 3])
D_mod  <- SIER_solution[, "D"]

# Plots data and solution from parameters.
par(mfrow = c(1, 2))
plot(t_data, C_data, xlab="t", ylab="C")
lines(t, C_mod)
plot(t_data, D_data, xlab="t", ylab="D")
lines(t, D_mod)